//회원 정보를 담는 DTO
package com.test.eh;

public class MemberDTO
{
	private String nikName;
	//private String 

	public String getNikName()
	{
		return nikName;
	}

	public void setNikName(String nikName)
	{
		this.nikName = nikName;
	}
	
	
}
